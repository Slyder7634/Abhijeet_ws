CHALLAN GENERATOR - WINDOWS PACKAGING KIT
==========================================

What this is
-------------
This folder turns your app into a single ChallanGenerator.exe that any
Windows user can double-click - no Python, no manual setup, no console
window. It bundles the desktop GUI (main.py) together with the local
backend (backend.py, for search/edit/history) into one app, and fixed a
couple of things that would otherwise break in a packaged exe:

  - main.py was calling "requests" and pdf_utils.py was calling PyMuPDF
    ("fitz"), but neither was listed in requirements.txt - added both.
  - The app used to store its data (companies, generated PDFs, saved
    submissions) next to the .py files. A packaged exe unpacks itself into
    a temporary folder that gets wiped on every close, so I added a small
    paths.py helper that now stores that data permanently in
    %LOCALAPPDATA%\ChallanGenerator instead, and seeds it with your
    existing template PDF and coordinate config the first time it runs.
  - backend.py ran Flask with debug=True, which isn't safe/stable when run
    inside a background thread of a packaged app - switched to
    debug=False, use_reloader=False.
  - Added app_launcher.py, a single entry point that starts the backend
    quietly in the background, then opens the GUI - so the user only ever
    sees one window, not two programs.

One important limitation: building a Windows .exe has to happen ON a
Windows machine - it can't be cross-built from here. That's a PyInstaller
requirement, not something specific to this app. So there's one manual
step below, and it only needs to happen once.


STEP 1 - Build the .exe (do this once, on any Windows 10/11 PC)
------------------------------------------------------------------
1. Make sure Python 3.10+ is installed on that PC
   (https://www.python.org/downloads - tick "Add Python to PATH" during
   install).
2. Copy this whole folder to that PC.
3. Double-click build_windows.bat.
   It will: create a private build environment, install the required
   packages, build ChallanGenerator.exe, install it to
   %LOCALAPPDATA%\ChallanGenerator, and put a "Challan Generator" icon on
   that PC's Desktop automatically.
4. The first build takes a few minutes (downloading packages + compiling).
   When it says "Done!", you're finished with this step.

The finished file is at: dist\ChallanGenerator.exe
This one file is fully standalone (~150-250 MB, since it bundles Python
and PyQt6 inside it) - it does NOT need Python installed to run.


STEP 2 - Give it to other Windows users
------------------------------------------
Once you have ChallanGenerator.exe from Step 1, you have two options:

  Option A (simplest): send them ChallanGenerator.exe directly (e.g. via a
  shared drive or USB stick). They can just double-click it to run - no
  install needed. If they want a Desktop icon, they right-click the file
  and choose "Send to > Desktop (create shortcut)".

  Option B (nicer): send them ChallanGenerator.exe plus the small
  install_shortcut.bat included in this folder. They put both files in the
  same folder and double-click install_shortcut.bat once - it copies the
  app to their account and adds a proper "Challan Generator" Desktop icon,
  the same way Step 1 did for you. No Python needed on their PC either.

Each user's data (saved companies, generated Bills/Challans, submission
history) is kept separately on their own PC, at
%LOCALAPPDATA%\ChallanGenerator.


Notes
-----
- config\companies.json in this folder currently ships with the company
  data that was already in your project. Edit or clear it before building
  if you don't want that pre-filled for new installs.
- The app works fully offline with local storage. If you also want
  multiple users sharing one live database, that needs a real MongoDB
  server reachable from every PC (edit MONGODB_URI at the top of
  backend.py) - by default it quietly falls back to a local file per PC.
