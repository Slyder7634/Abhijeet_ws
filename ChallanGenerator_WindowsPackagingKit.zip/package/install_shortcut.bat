@echo off
setlocal
title Installing Challan Generator
cd /d "%~dp0"

if not exist "ChallanGenerator.exe" (
    echo [ERROR] ChallanGenerator.exe was not found in this folder.
    echo Put install_shortcut.bat in the same folder as ChallanGenerator.exe and run it again.
    pause
    exit /b 1
)

set "INSTALL_DIR=%LOCALAPPDATA%\ChallanGenerator"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /y "ChallanGenerator.exe" "%INSTALL_DIR%\ChallanGenerator.exe" >nul

powershell -NoProfile -Command ^
  "$s=(New-Object -COM WScript.Shell).CreateShortcut(\"$env:USERPROFILE\Desktop\Challan Generator.lnk\");" ^
  "$s.TargetPath='%INSTALL_DIR%\ChallanGenerator.exe';" ^
  "$s.WorkingDirectory='%INSTALL_DIR%';" ^
  "$s.IconLocation='%INSTALL_DIR%\ChallanGenerator.exe';" ^
  "$s.Save()"

echo.
echo Done! A "Challan Generator" icon is now on your Desktop.
pause
