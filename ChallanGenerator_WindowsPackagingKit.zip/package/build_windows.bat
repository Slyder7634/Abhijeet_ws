@echo off
setlocal enabledelayedexpansion
title Challan Generator - Build and Install
cd /d "%~dp0"

echo ============================================================
echo  Challan Generator - Build ^& Install for Windows
echo ============================================================
echo.

REM ---- 1. Check Python is available ----
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found on this PC.
    echo Please install Python 3.10 or later from https://www.python.org/downloads/
    echo During install, check the box "Add Python to PATH", then run this file again.
    pause
    exit /b 1
)

echo [1/6] Creating a private build environment...
python -m venv build_env
if errorlevel 1 (
    echo [ERROR] Could not create the virtual environment.
    pause
    exit /b 1
)

call build_env\Scripts\activate.bat

echo [2/6] Installing app requirements (this can take a few minutes)...
python -m pip install --upgrade pip >nul
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install requirements.
    pause
    exit /b 1
)

echo [3/6] Installing packaging tool (PyInstaller)...
pip install pyinstaller
if errorlevel 1 (
    echo [ERROR] Failed to install PyInstaller.
    pause
    exit /b 1
)

echo [4/6] Building ChallanGenerator.exe...
pyinstaller --noconfirm --clean --onefile --windowed ^
  --name "ChallanGenerator" ^
  --add-data "config;config" ^
  --add-data "templates;templates" ^
  --add-data "challan copy.pdf;." ^
  --hidden-import bson ^
  --hidden-import pymongo ^
  app_launcher.py
if errorlevel 1 (
    echo [ERROR] Build failed. Scroll up for details.
    pause
    exit /b 1
)

echo [5/6] Installing the app to your account...
set "INSTALL_DIR=%LOCALAPPDATA%\ChallanGenerator"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /y "dist\ChallanGenerator.exe" "%INSTALL_DIR%\ChallanGenerator.exe" >nul

echo [6/6] Creating a Desktop shortcut...
powershell -NoProfile -Command ^
  "$s=(New-Object -COM WScript.Shell).CreateShortcut(\"$env:USERPROFILE\Desktop\Challan Generator.lnk\");" ^
  "$s.TargetPath='%INSTALL_DIR%\ChallanGenerator.exe';" ^
  "$s.WorkingDirectory='%INSTALL_DIR%';" ^
  "$s.IconLocation='%INSTALL_DIR%\ChallanGenerator.exe';" ^
  "$s.Save()"

call build_env\Scripts\deactivate.bat >nul 2>nul

echo.
echo ============================================================
echo  Done! A "Challan Generator" icon is now on your Desktop.
echo  Double-click it any time to open the app.
echo ============================================================
echo.
pause
