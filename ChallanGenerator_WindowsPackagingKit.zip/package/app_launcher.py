"""
Single entry point for the packaged app.

Starts the local backend (search / edit / save history) quietly in a
background thread, then opens the Challan Generator window. If the backend
fails to start for any reason, the GUI still runs fine using its local
fallback (companies are saved locally either way).
"""

import sys
import os
import threading
import time


def _start_backend():
    try:
        import backend
        backend.app.run(
            host="127.0.0.1",
            port=5173,
            debug=False,
            use_reloader=False,
            threaded=True,
        )
    except Exception as exc:  # pragma: no cover - best effort background service
        print(f"Backend server did not start (continuing without it): {exc}")


def main():
    backend_thread = threading.Thread(target=_start_backend, daemon=True)
    backend_thread.start()
    time.sleep(0.8)  # give the backend a moment to bind its port

    import main as gui_main
    gui_main.main()


if __name__ == "__main__":
    main()
