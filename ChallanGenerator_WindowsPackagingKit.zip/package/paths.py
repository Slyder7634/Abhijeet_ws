"""
Path helpers so the app works both:
  - running from source (python main.py)
  - packaged as a single Windows .exe with PyInstaller

When frozen, PyInstaller unpacks bundled files into a temporary folder
(sys._MEIPASS) that is wiped after the app closes, so it can't be used to
store user data (companies, generated PDFs, saved submissions). Instead we
use a permanent folder under the user's AppData, and copy the bundled
starter files (template PDF, default config) there the first time the app
runs.
"""

import os
import sys
import shutil

APP_FOLDER_NAME = "ChallanGenerator"


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def get_resource_dir() -> str:
    """Read-only folder containing bundled files (template PDF, default config)."""
    if is_frozen():
        return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(sys.executable)))
    return os.path.dirname(os.path.abspath(__file__))


def get_base_dir() -> str:
    """Writable, persistent folder for user data (config, generated PDFs, submissions)."""
    if is_frozen():
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        base = os.path.join(root, APP_FOLDER_NAME)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(base, exist_ok=True)
    return base


def seed_user_data(base_dir: str, resource_dir: str) -> None:
    """Copy bundled starter files into the persistent base_dir the first time
    the app runs there, without overwriting anything the user already has."""
    if os.path.normcase(base_dir) == os.path.normcase(resource_dir):
        return  # dev mode: nothing to seed, it's the same folder

    # Template PDF used to generate Bills/Challans
    src_template = os.path.join(resource_dir, "challan copy.pdf")
    dst_template = os.path.join(base_dir, "challan copy.pdf")
    if os.path.exists(src_template) and not os.path.exists(dst_template):
        shutil.copy2(src_template, dst_template)

    # Config folder (coordinates + saved companies)
    src_config = os.path.join(resource_dir, "config")
    dst_config = os.path.join(base_dir, "config")
    os.makedirs(dst_config, exist_ok=True)
    if os.path.isdir(src_config):
        for fname in os.listdir(src_config):
            src_f = os.path.join(src_config, fname)
            dst_f = os.path.join(dst_config, fname)
            if os.path.isfile(src_f) and not os.path.exists(dst_f):
                shutil.copy2(src_f, dst_f)

    # Optional fallback templates folder
    src_templates = os.path.join(resource_dir, "templates")
    dst_templates = os.path.join(base_dir, "templates")
    if os.path.isdir(src_templates):
        os.makedirs(dst_templates, exist_ok=True)
        for fname in os.listdir(src_templates):
            src_f = os.path.join(src_templates, fname)
            dst_f = os.path.join(dst_templates, fname)
            if os.path.isfile(src_f) and not os.path.exists(dst_f):
                shutil.copy2(src_f, dst_f)
